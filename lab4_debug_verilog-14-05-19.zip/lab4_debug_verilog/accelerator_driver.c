#include "xparameters.h"
#include "accelerator.h"
#include "stdlib.h"
#include "xil_io.h"

int *accelerator_driver ( int size, int *x_vector )
{
	const int MAX_SIZE = 512;
	const long long int ENABLER = 0xFFFFFFFD;
	const long long int TRIGGER = 0xFFFFFFFC;

	int *y_vector;
	int i;

	if (  size > MAX_SIZE )
		return NULL;

	y_vector = malloc ( sizeof(int) * size );

	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, ENABLER);

	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, size);


	for ( i = 0; i < size; i++ )
	{
		 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, x_vector[i]);

	}
	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 4, 1);


	while(1)
	{


	if (  ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 12) != 0)
		{
			xil_printf("IN READ: Got here in for time!\r\n");
			for ( i = 0; i < size; i ++)
			{
				y_vector[i] =  ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 8);
			}

			break;
		}

	}

	return y_vector;
}

int main (void) {

    int *x_vector, *y_vector;
    int size = 24;
    int i = 0;

    x_vector = malloc ( sizeof(int) * size );

    for ( i = 0; i < size; i++)
    	x_vector[i] = i;

    xil_printf("START!\r\n");
    y_vector = accelerator_driver ( size, x_vector );

    for ( i = 0; i < size; i++)
        	xil_printf("RESULT: Y = %d\r\n", y_vector[i] );

    xil_printf("====================================\n\r");

    y_vector = accelerator_driver ( size, x_vector );
    for ( i = 0; i < size; i++)
            xil_printf("RESULT: Y = %d\r\n", y_vector[i] );

    return 0;
}


