#include "xparameters.h"
#include "accelerator.h"
#include "stdlib.h"
int *accelerator_driver ( int size, int *x_vector )
{
	const int MAX_SIZE = 256;
	const int ENABLER = 0xFFFFFFFD;
	const int TRIGGER = 0xFFFFFFFF;

	int *y_vector;
	int i;

	if (  size > MAX_SIZE )
		return NULL;

	y_vector = malloc ( sizeof(int) * size );
	
	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S_AXI_BASEADDR, 0, ENABLER);
	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S_AXI_BASEADDR, 0, size);
	for ( i = 0; i < size; i++ )
	{
		 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S_AXI_BASEADDR, 0, x_vector[i]);
	}
	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S_AXI_BASEADDR, 0, TRIGGER);

	while(1)
	{
		if (  ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S_AXI_BASEADDR, 1) == 1)
		{

			for ( i = 0; i < size; i ++)
			{
				y_vector[i] =  ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S_AXI_BASEADDR, 0);
			}

			break;
		}
	}

	return y_vector;
}

int main (void) {


}
