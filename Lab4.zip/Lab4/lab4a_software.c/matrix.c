#include <stdio.h>
#include <stdlib.h>
#include "coremark.h"
#include "timer_util.h"
#include "xscutimer.h"
#include "xil_printf.h"

#define N 256
#define constantA 2

//#define xil_printf printf

int main()
{

	int x_vector[N];
	int y_vector[N];
	int i;

	srand(173);

	for ( i = 0; i < N; i++ )
	{
		x_vector[i] = rand() % 100;
		y_vector[i] = 0;
	}

	// Make X*X vector //
	for ( i = 0; i < N; i++ )
	{

		y_vector[i] = constantA *  x_vector[i] * x_vector[i];
	}

	return (0);

}
