#include "xparameters.h"
#include "accelerator.h"
#include "stdlib.h"
#include "xil_io.h"

int *accelerator_driver ( int size, int *x_vector )
{
	const int MAX_SIZE = 256;
	const long long int ENABLER = 0xFFFFFFFD;
	const long long int TRIGGER = 0xFFFFFFFC;

	int *y_vector;
	int i, j = 0;

	if (  size > MAX_SIZE )
		return NULL;

	y_vector = malloc ( sizeof(int) * size );
	
	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, ENABLER);
	 //xil_printf("ENABLER = %d\n\r",ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0) );

	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, size);
	// xil_printf("size = %d\n\r",ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0) );

	for ( i = 0; i < size; i++ )
	{
		 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, x_vector[i]);
		// xil_printf("X VECTOR = %d\n\r",ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0) );
	}
	 ACCELERATOR_mWriteReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0, TRIGGER);
	 //xil_printf("Trigger = %d\n\r",ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 0) );

	while(1)
	{

		//xil_printf("valid output = %d\n\r",ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR,12) );
		//xil_printf("output data = %d\n\r",ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 8) );

		if (  ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 12) != 0)
		{
			xil_printf("IN READ: Got here in for %d time!\r\n", j++);
			for ( i = 0; i < size; i ++)
			{
				y_vector[i] =  ACCELERATOR_mReadReg(XPAR_ACCELERATOR_0_S00_AXI_BASEADDR, 8);
			}

			break;
		}
		//xil_printf("Geia sou malaka paok!\r\n");
	}

	return y_vector;
}

int main (void) {

    int *x_vector, *y_vector;
    int size = 64;
    int i = 0;

    x_vector = malloc ( sizeof(int) * size );

    for ( i = 0; i < size; i++)
    	x_vector[i] = i;

    xil_printf("MPHKE!\r\n");
    y_vector = accelerator_driver ( size, x_vector );

    for ( i = 0; i < size; i++)
        	xil_printf("GAMW TO SPITI SOU GIA ERGASIA y = %d\r\n", y_vector[i] );

    return 0;
}


